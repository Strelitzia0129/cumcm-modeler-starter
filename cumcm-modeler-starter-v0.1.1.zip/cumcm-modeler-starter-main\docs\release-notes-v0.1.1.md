# v0.1.1 — Maintenance release

常规维护升级：更新依赖约束与官方支持的 Python 版本，同步完善文档。

## Highlights

- 依赖约束上移，与当前主流稳定版本对齐：
  `numpy>=2.1`、`pandas>=3.0`、`scipy>=1.14`、`scikit-learn>=1.6`、
  `statsmodels>=0.15`、`matplotlib>=3.10`、`networkx>=3.4`、`ruff>=0.12`。
- 官方支持 Python 3.11–3.14，CI 矩阵新增 3.13 与 3.14。
- README、README.en、CITATION 与 CHANGELOG 同步更新至 v0.1.1。

## Verified

- 8 个单元测试全部通过。
- 完整建模示例在 numpy 2.5.4 / pandas 3.1.0 / scikit-learn 1.9.1 /
  scipy 1.18.1 / statsmodels 0.15.0 / matplotlib 3.11.2 下运行通过。

## Install

```bash
python -m pip install .
cumcm-starter check-env
cumcm-starter demo --out demo_output
```

## Important notes

- 本项目非官方，不保证竞赛奖项。
- 示例数据为合成数据，不代表任何赛题结论。
- 竞赛规则和 AI 要求以当届官方网站为准。
- 外部教材和官方文件未被复制进仓库，第三方权利归原权利人。
