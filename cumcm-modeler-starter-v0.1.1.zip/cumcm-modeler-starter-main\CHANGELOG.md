# Changelog

本项目遵循 [Keep a Changelog](https://keepachangelog.com/zh-CN/1.1.0/) 的结构，并使用语义化版本号。

## [Unreleased]

### Planned

- 为更多算法卡补充小型可复现案例。
- 增加真题的“问题类型标签”，不提供标准答案。
- 增加 MATLAB 等价基线。

## [0.1.1] - 2026-10-23

### Changed

- 依赖约束上移：`numpy>=2.1`、`pandas>=3.0`、`scipy>=1.14`、`scikit-learn>=1.6`、`statsmodels>=0.15`、`matplotlib>=3.10`、`networkx>=3.4`、`ruff>=0.12`。
- 官方支持 Python 3.11–3.14，并在 CI 矩阵中增加 3.13 与 3.14。
- README、README.en、CITATION 与发布说明同步更新至 v0.1.1。

### Verified

- 8 个单元测试全部通过。
- 完整建模示例在 numpy 2.5.4 / pandas 3.1.0 / scikit-learn 1.9.1 / scipy 1.18.1 / statsmodels 0.15.0 / matplotlib 3.11.2 下运行通过。

## [0.1.0] - 2026-08-11

### Added

- 21 张可搜索算法卡与离线导航页。
- 34 条官方或权威资料入口。
- 30 天冲刺计划和 AI 使用留痕模板。
- Python CLI、TOPSIS 与敏感性分析模块。
- 完整建模基线示例。
- 单元测试、仓库审计、CI 和 GitHub Pages 工作流。
- 开源许可证、贡献指南、安全政策与社区模板。

